package com.example.abdull.fetchscore;

/**
 * Created by abdull on 3/14/17.
 */

public interface Fahad {

    void matchWatch();
    void Eat();

}
