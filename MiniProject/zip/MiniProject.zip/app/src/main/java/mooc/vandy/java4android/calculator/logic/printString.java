package mooc.vandy.java4android.calculator.logic;

/**
 * Created by Engr.Uzma on 28/07/2016.
 */
// interface for printing output

public interface printString {

    // used this interface method to print the output on the screen
    public void print(String calculation);
}
